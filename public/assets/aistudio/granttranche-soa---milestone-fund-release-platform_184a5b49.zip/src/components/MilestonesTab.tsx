import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  Clock, 
  Lock, 
  Upload, 
  Check, 
  X, 
  Send, 
  Calendar, 
  FileText,
  AlertCircle,
  AlertTriangle,
  ShieldCheck
} from 'lucide-react';
import { simulationEngine } from '../services/simulationEngine';
import { Milestone, UserProfile } from '../types/soa';
import { formatRupees } from '../utils/formatters';

interface MilestonesTabProps {
  currentUser: UserProfile;
}

export const MilestonesTab: React.FC<MilestonesTabProps> = ({ currentUser }) => {
  const [, setTick] = useState(0);
  const [selectedMilestone, setSelectedMilestone] = useState<Milestone | null>(null);
  const [evidenceModalOpen, setEvidenceModalOpen] = useState(false);
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [decisionModalMode, setDecisionModalMode] = useState<'APPROVE' | 'REJECT'>('APPROVE');

  // Confirmation Modal State (Fix 1)
  const [confirmApprovalMilestone, setConfirmApprovalMilestone] = useState<Milestone | null>(null);
  const [isConfirmingApproval, setIsConfirmingApproval] = useState(false);

  // Evidence Form
  const [evidenceTitle, setEvidenceTitle] = useState('');
  const [evidenceDescription, setEvidenceDescription] = useState('');
  const [evidenceMetrics, setEvidenceMetrics] = useState('');

  // Review Form
  const [reviewComments, setReviewComments] = useState('');
  const [alertMessage, setAlertMessage] = useState<string | null>(null);

  // Subscribe to simulation updates
  useEffect(() => {
    const unsubscribe = simulationEngine.subscribe(() => {
      setTick((t) => t + 1);
    });
    return unsubscribe;
  }, []);

  const activeGrant = simulationEngine.activeGrant;
  const milestones = simulationEngine.activeMilestones;
  const tranches = simulationEngine.activeTranches;
  const evidenceList = simulationEngine.evidenceSubmissions;

  const handleOpenEvidence = (m: Milestone) => {
    setSelectedMilestone(m);
    setEvidenceTitle(`Milestone ${m.milestoneNumber} Deliverable Report & Field Data`);
    setEvidenceDescription(`Comprehensive operational verification report fulfilling all scheduled milestone deliverables.`);
    setEvidenceMetrics(`All benchmark KPIs achieved (>85% efficiency, zero downtime, validated logbook).`);
    setEvidenceModalOpen(true);
  };

  const handleOpenApprovalConfirmation = (m: Milestone) => {
    setConfirmApprovalMilestone(m);
  };

  const handleConfirmApproval = (m: Milestone) => {
    if (isConfirmingApproval) return;
    setIsConfirmingApproval(true);

    const res = simulationEngine.reviewMilestone(
      m.id,
      'APPROVE',
      'Independent scientific audit verified laboratory logs and data. Approved for immediate tranche release.'
    );

    setTimeout(() => {
      setIsConfirmingApproval(false);
      setConfirmApprovalMilestone(null);
      if (res.success) {
        setAlertMessage(`Milestone approved. Tranche ${m.milestoneNumber} authorized for release.`);
      } else {
        setAlertMessage(res.message);
      }
      setTimeout(() => setAlertMessage(null), 5000);
    }, 200);
  };

  const handleOpenReview = (m: Milestone, mode: 'APPROVE' | 'REJECT') => {
    setSelectedMilestone(m);
    setDecisionModalMode(mode);
    setReviewComments(
      mode === 'APPROVE'
        ? 'Independent scientific audit verified laboratory logs and data. Approved for immediate tranche release.'
        : 'Telemetry data shows intermittent flow fluctuations failing stability threshold. Resubmission required.'
    );
    setReviewModalOpen(true);
  };

  const handleSubmitEvidence = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMilestone) return;

    const res = simulationEngine.submitEvidence(
      selectedMilestone.id,
      evidenceTitle,
      evidenceDescription,
      evidenceMetrics
    );

    if (res.success) {
      setAlertMessage(res.message);
      setEvidenceModalOpen(false);
      setTimeout(() => setAlertMessage(null), 5000);
    }
  };

  const handleRecordDecision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMilestone) return;

    const res = simulationEngine.reviewMilestone(
      selectedMilestone.id,
      decisionModalMode,
      reviewComments
    );

    if (res.success) {
      if (decisionModalMode === 'APPROVE') {
        setAlertMessage(`Milestone approved. Tranche ${selectedMilestone.milestoneNumber} authorized for release.`);
      } else {
        setAlertMessage('Milestone was rejected with reviewer feedback sent to applicant.');
      }
      setReviewModalOpen(false);
      setTimeout(() => setAlertMessage(null), 5000);
    } else {
      setAlertMessage(res.message);
      setTimeout(() => setAlertMessage(null), 5000);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {alertMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex items-center justify-between">
          <span>{alertMessage}</span>
          <button onClick={() => setAlertMessage(null)} className="text-slate-500 hover:text-slate-800">Dismiss</button>
        </div>
      )}

      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="text-xs text-slate-500">Active Grant: <strong className="text-slate-800">{activeGrant.grantCode}</strong></div>
            <h1 className="text-xl font-bold text-slate-900 mt-0.5">{activeGrant.title}</h1>
            <p className="text-xs text-slate-500 mt-1">
              Review milestone deliverables, track completion deadlines, and verify compliance.
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-500">Total Milestones</span>
            <div className="text-xl font-bold text-slate-900">{milestones.length}</div>
          </div>
        </div>
      </div>

      {/* Milestones List */}
      <div className="space-y-3">
        {milestones.map((milestone) => {
          const tranche = tranches.find((t) => t.id === milestone.trancheId);
          const isDisbursed = tranche?.status === 'DISBURSED';
          const isApproved = milestone.status === 'APPROVED';
          const isSubmitted = milestone.status === 'EVIDENCE_SUBMITTED';
          const evidence = evidenceList.filter((e) => e.milestoneId === milestone.id);

          return (
            <div
              key={milestone.id}
              className={`bg-white p-5 rounded-xl border shadow-sm transition space-y-3 ${
                isDisbursed
                  ? 'border-emerald-300 ring-1 ring-emerald-200'
                  : isSubmitted
                  ? 'border-indigo-200'
                  : 'border-slate-200'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="font-semibold text-slate-700">Milestone {milestone.milestoneNumber}</span>
                    <span className="text-slate-300">·</span>
                    <span className="font-mono text-slate-500">{milestone.id}</span>
                    <span className="text-slate-300">·</span>
                    <span className="text-slate-500 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      Target Date: {milestone.targetDate}
                    </span>
                    <span className="text-slate-300">·</span>

                    {isDisbursed ? (
                      <span className="text-emerald-700 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Approved & Released
                      </span>
                    ) : isSubmitted ? (
                      <span className="text-indigo-700 font-semibold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> Evidence Submitted (Under Review)
                      </span>
                    ) : (
                      <span className="text-slate-500 flex items-center gap-1">
                        <Lock className="w-3.5 h-3.5" /> Pending Evidence
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-bold text-slate-900">{milestone.title}</h3>
                  <p className="text-xs text-slate-600">{milestone.description}</p>

                  <div className="pt-2">
                    <span className="text-[11px] font-semibold text-slate-500 block mb-1">Deliverables:</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-xs text-slate-600">
                      {milestone.deliverables.map((d, i) => (
                        <div key={i} className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
                          <span>{d}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {evidence.length > 0 && (
                    <div className="mt-2 p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                      <span className="text-indigo-700 font-medium">Submitted Evidence: {evidence[0].title}</span>
                      <p className="text-slate-500 text-[11px] mt-0.5">{evidence[0].metricsAchieved}</p>
                    </div>
                  )}
                </div>

                {/* Right: Tranche & Actions */}
                <div className="sm:w-60 bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col justify-between shrink-0">
                  <div>
                    <span className="text-xs text-slate-500">Tranche Allocation</span>
                    <div className="text-xl font-bold text-slate-900 tabular-nums">
                      {formatRupees(milestone.trancheAmount)}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1">Status: <strong className={isDisbursed ? 'text-emerald-700' : 'text-amber-700'}>{tranche?.status}</strong></div>
                  </div>

                  <div className="mt-4 space-y-2">
                    {isDisbursed ? (
                      <div className="w-full py-1.5 bg-emerald-100 text-emerald-800 text-xs text-center rounded font-medium">
                        Funds Disbursed
                      </div>
                    ) : currentUser.role === 'grantee' ? (
                      <button
                        onClick={() => handleOpenEvidence(milestone)}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium py-2 rounded-lg transition flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isSubmitted ? 'Update Evidence' : 'Submit Evidence'}</span>
                      </button>
                    ) : currentUser.role === 'grantReviewer' && isSubmitted ? (
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => handleOpenApprovalConfirmation(milestone)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium py-1.5 rounded transition"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleOpenReview(milestone, 'REJECT')}
                          className="bg-white hover:bg-rose-50 text-rose-700 border border-slate-200 text-xs font-medium py-1.5 rounded transition"
                        >
                          Reject
                        </button>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-400 text-center py-1">
                        {isSubmitted ? 'Awaiting Reviewer Sign-off' : 'Awaiting Applicant Evidence'}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Evidence */}
      {evidenceModalOpen && selectedMilestone && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 shadow-xl relative">
            <button onClick={() => setEvidenceModalOpen(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600">
              <X className="w-5 h-5" />
            </button>
            <h3 className="text-lg font-bold text-slate-900 mb-1">Submit Milestone {selectedMilestone.milestoneNumber} Evidence</h3>
            <p className="text-xs text-slate-500 mb-4">{selectedMilestone.title}</p>
            <form onSubmit={handleSubmitEvidence} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Dossier Title *</label>
                <input
                  type="text"
                  value={evidenceTitle}
                  onChange={(e) => setEvidenceTitle(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Operational Results & Summary *</label>
                <textarea
                  rows={3}
                  value={evidenceDescription}
                  onChange={(e) => setEvidenceDescription(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Key Metrics Achieved *</label>
                <input
                  type="text"
                  value={evidenceMetrics}
                  onChange={(e) => setEvidenceMetrics(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900"
                />
              </div>
              <div className="flex items-center justify-end gap-3 pt-2">
                <button type="button" onClick={() => setEvidenceModalOpen(false)} className="px-4 py-2 text-xs text-slate-500 hover:text-slate-800">Cancel</button>
                <button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white font-medium px-4 py-2 rounded-lg text-xs shadow-sm">Submit to Reviewer</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Review */}
      {reviewModalOpen && selectedMilestone && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 shadow-xl relative">
            <button onClick={() => setReviewModalOpen(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600">
              <X className="w-5 h-5" />
            </button>
            <h3 className="text-lg font-bold text-slate-900 mb-1">Official Review Decision</h3>
            <p className="text-xs text-slate-500 mb-4">{selectedMilestone.title}</p>
            <form onSubmit={handleRecordDecision} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDecisionModalMode('APPROVE')}
                  className={`p-3 rounded-lg border text-xs font-semibold ${decisionModalMode === 'APPROVE' ? 'bg-emerald-50 border-emerald-500 text-emerald-900' : 'bg-slate-50 text-slate-600'}`}
                >
                  Approve ({formatRupees(selectedMilestone.trancheAmount)})
                </button>
                <button
                  type="button"
                  onClick={() => setDecisionModalMode('REJECT')}
                  className={`p-3 rounded-lg border text-xs font-semibold ${decisionModalMode === 'REJECT' ? 'bg-rose-50 border-rose-500 text-rose-900' : 'bg-slate-50 text-slate-600'}`}
                >
                  Reject
                </button>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Review Notes *</label>
                <textarea
                  rows={4}
                  value={reviewComments}
                  onChange={(e) => setReviewComments(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900"
                />
              </div>
              <div className="flex items-center justify-end gap-3 pt-2">
                <button type="button" onClick={() => setReviewModalOpen(false)} className="px-4 py-2 text-xs text-slate-500 hover:text-slate-800">Cancel</button>
                <button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white font-medium px-4 py-2 rounded-lg text-xs shadow-sm">Submit Decision</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Double-Confirmation Approval Modal (Fix 1) */}
      {confirmApprovalMilestone && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 shadow-xl relative animate-in fade-in duration-150">
            <button
              onClick={() => {
                if (!isConfirmingApproval) setConfirmApprovalMilestone(null);
              }}
              disabled={isConfirmingApproval}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1"
              title="Cancel"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-emerald-800 font-semibold text-xs mb-1">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Reviewer Authorization Step</span>
            </div>

            <h3 className="text-lg font-bold text-slate-900">
              Confirm Milestone Approval & Tranche Release
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Please verify the milestone details and grant allocation before confirming authorization.
            </p>

            {/* Details Box */}
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 mt-4 space-y-2.5 text-xs">
              <div className="flex justify-between items-start">
                <span className="text-slate-500">Grant Name:</span>
                <span className="font-semibold text-slate-900 text-right max-w-[280px]">
                  {activeGrant.title} ({activeGrant.grantCode})
                </span>
              </div>

              <div className="flex justify-between items-start">
                <span className="text-slate-500">Milestone Name:</span>
                <span className="font-semibold text-slate-900 text-right max-w-[280px]">
                  Milestone {confirmApprovalMilestone.milestoneNumber}: {confirmApprovalMilestone.title}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-500">Associated Tranche:</span>
                <span className="font-semibold text-slate-900 font-mono">
                  Tranche {confirmApprovalMilestone.milestoneNumber} ({confirmApprovalMilestone.trancheId})
                </span>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                <span className="text-slate-600 font-medium">Tranche Amount:</span>
                <span className="text-base font-bold text-emerald-700 font-mono">
                  {formatRupees(confirmApprovalMilestone.trancheAmount)}
                </span>
              </div>
            </div>

            {/* Warning Box */}
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-4 flex items-start gap-2.5 text-xs text-amber-900">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong>Warning:</strong> This action will approve Milestone {confirmApprovalMilestone.milestoneNumber} and authorize only its associated Tranche {confirmApprovalMilestone.milestoneNumber} ({formatRupees(confirmApprovalMilestone.trancheAmount)}). Downstream tranches will remain locked until subsequent milestones pass review.
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setConfirmApprovalMilestone(null)}
                disabled={isConfirmingApproval}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-medium transition disabled:opacity-50"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={() => handleConfirmApproval(confirmApprovalMilestone)}
                disabled={isConfirmingApproval}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition flex items-center gap-1.5 disabled:opacity-50"
              >
                {isConfirmingApproval ? (
                  <span>Authorizing...</span>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Confirm Approval & Release</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
