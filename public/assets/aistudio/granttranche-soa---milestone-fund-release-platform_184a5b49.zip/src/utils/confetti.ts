import confetti from 'canvas-confetti';

export function fireReleaseConfetti(): void {
  // Celebration animations removed per user requirements
}
